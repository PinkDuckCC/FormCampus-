package pub.developers.forum.common.constant;

/**
 * @author Qiangqiang.Bian
 * @create 2020/10/19
 * @desc
 **/
public interface Constant {

    String REQUEST_HEADER_TOKEN_KEY = "token";
    String REQUEST_QUERY_TOKEN_KEY = "token";

}
